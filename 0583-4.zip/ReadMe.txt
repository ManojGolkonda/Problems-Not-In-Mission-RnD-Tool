1.To delete special characters in a given string : string_spl.c

2.To Change the string according to number of repeations of characters : string_count.c

3.To find the sum of unique numbers of a sequence : unique_sum.c

4.To find the sequence giving maximum sum : max_sum_sequence.c