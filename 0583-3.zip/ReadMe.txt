1.sort_array_012.c :sorts a given array consisting of 0's, 1's and 2's.

2.sort_array_misplace.c :sorts given sorted array having two misplaced elements.

3.triangle.c :finds the type of triangle based on the given vertices.

4.find_greater_lesser_nums.c :finds the number of elements greater and lesser than a given element in an unsorted array.

5.date_validate.c :validates the given date i.e. checks whether the date is valid or not.

6.date_eng.c :converts the given date into english if it is valid.

