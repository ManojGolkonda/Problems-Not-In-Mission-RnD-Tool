1. addFromLeft.c :- Given two number strings of same length.Add them from left to right and return the output.

2. arrayMultiplier.c :- Given two unsigned int arrays a and b. a can be of max length 10 and b can be of 5. Multiply the numbers formed by the binary representation of all the numbers of a i.e in all positions. a[0] will be the least significant digits of the number formed,so on.

3. baseMinusTwo.c :- Given an integer.Convert that into a number system with base -2 i.e. negabinary number. :)

4. binaryToOctal.c :- Given a binary number/string. Convert it into Octal number system without any intermediate conversion to any other system.

5. findLengthOfArray.c :- Given an integer array of unknown length. We have to find the length of that array. That array have the following properties i) all the n numbers of the array are in the ascending order where n is the length of the array. ii) array[n] > n   iii)a[n+1]<a[n]      iv)after that n 0's are there i.e from a[n+2] to a[2n+2] are 0's. v)remaing can be anything.

6.numPermute.c :- Given an 8 digit number without repetitions. We have to print all the possible combination of that number in the ascending order. :)

